'use client'

import { useEffect, useMemo, useState } from 'react'
import { io, Socket } from 'socket.io-client'
import { motion } from 'framer-motion'

type ScanEvent =
  | { type: 'scan_started'; target: string; scanId: string }
  | { type: 'scan_progress'; scanId: string; progress: number; message: string }
  | {
      type: 'vuln_found'
      scanId: string
      vuln: {
        type: string
        severity: string
        target: string
        validationStatus: string
        payloadUsed: string
        evidence: string
        technicalAnalysis: string
        impact: string
        exploitability: string
        confidenceScore: number
        remediation: string
      }
    }
  | { type: 'scan_finished'; scanId: string; summary: any }
  | { type: 'error'; scanId?: string; message: string }

const BACKEND_WS_URL = process.env.NEXT_PUBLIC_BACKEND_WS_URL || 'http://localhost:8000/ws'

export default function HomePage() {
  const [socketState, setSocketState] = useState<'disconnected' | 'connected'>('disconnected')
  const [scanTarget, setScanTarget] = useState('https://example.com')
  const [scanId, setScanId] = useState<string>('')
  const [progress, setProgress] = useState(0)
  const [message, setMessage] = useState('Menunggu...')
  const [vulns, setVulns] = useState<any[]>([])

  const socket: Socket | null = useMemo(() => {
    const s = io(BACKEND_WS_URL, {
      transports: ['websocket'],
      autoConnect: true
    })
    return s
  }, [])

  useEffect(() => {
    if (!socket) return

    const onConnect = () => setSocketState('connected')
    const onDisconnect = () => setSocketState('disconnected')

    socket.on('connect', onConnect)
    socket.on('disconnect', onDisconnect)

    socket.on('event', (evt: ScanEvent) => {
      if (evt.type === 'scan_started') {
        setScanId(evt.scanId)
        setProgress(0)
        setMessage(`Scan dimulai: ${evt.target}`)
        setVulns([])
      }
      if (evt.type === 'scan_progress') {
        setProgress(evt.progress)
        setMessage(evt.message)
      }
      if (evt.type === 'vuln_found') {
        setVulns((prev) => [evt.vuln, ...prev])
      }
      if (evt.type === 'scan_finished') {
        setProgress(100)
        setMessage('Scan selesai')
      }
      if (evt.type === 'error') {
        setMessage(`Error: ${evt.message}`)
      }
    })

    return () => {
      socket.off('connect', onConnect)
      socket.off('disconnect', onDisconnect)
      socket.close()
    }
  }, [socket])

  const startScan = async () => {
    setMessage('Memulai...')
    setProgress(0)
    const res = await fetch('http://localhost:8000/api/scan/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target: scanTarget })
    })
    const data = await res.json()
    setScanId(data.scanId)
  }

  const exportReport = () => {
    const blob = new Blob([JSON.stringify({ scanId, vulns }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `report-${scanId || 'scan'}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <main className="min-h-screen px-6 py-10">
      <div className="mx-auto max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="flex items-start justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-white">AI Cyber Pentest Control Platform</h1>
              <p className="mt-2 text-sm text-slate-300">SOC-style real-time scanning dashboard</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
              <div className="text-xs text-slate-300">WebSocket</div>
              <div className="mt-1 text-lg font-semibold text-white">
                {socketState === 'connected' ? 'Connected' : 'Disconnected'}
              </div>
            </div>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
              <label className="text-sm text-slate-200">Target URL</label>
              <input
                className="mt-2 w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-white outline-none focus:border-blue-400"
                value={scanTarget}
                onChange={(e) => setScanTarget(e.target.value)}
              />
              <div className="mt-4 flex gap-3">
                <button
                  onClick={startScan}
                  className="rounded-xl bg-blue-500 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-600"
                >
                  Mulai Scan
                </button>
                <button
                  onClick={exportReport}
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white/90 hover:bg-white/10"
                >
                  Download JSON
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-300">Progress</div>
                  <div className="text-2xl font-bold text-white">{progress}%</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-300">Scan ID</div>
                  <div className="text-sm text-white/90 break-all">{scanId || '-'}</div>
                </div>
              </div>
              <div className="mt-4 h-3 overflow-hidden rounded-full bg-black/20">
                <motion.div
                  className="h-full bg-gradient-to-r from-blue-400 to-fuchsia-400"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <div className="mt-4 text-sm text-slate-200">{message}</div>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-white">Temuan</h2>
              <div className="text-sm text-slate-300">Total: {vulns.length}</div>
            </div>
            <div className="mt-4 space-y-3">
              {vulns.length === 0 ? (
                <div className="text-sm text-slate-300">Belum ada temuan.</div>
              ) : (
                vulns.map((v, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="rounded-xl border border-white/10 bg-black/20 p-4"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs text-slate-300">{v.type}</div>
                        <div className="font-semibold text-white">{v.severity} - {v.validationStatus}</div>
                      </div>
                      <div className="text-xs text-slate-300">Confidence: {v.confidenceScore}</div>
                    </div>
                    <div className="mt-2 text-sm text-slate-200">{v.evidence}</div>
                    <details className="mt-3">
                      <summary className="cursor-pointer text-sm font-semibold text-white/90">Lihat analisis SOC</summary>
                      <pre className="mt-3 whitespace-pre-wrap text-xs text-slate-200">{v.technicalAnalysis}</pre>
                    </details>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </main>
  )
}


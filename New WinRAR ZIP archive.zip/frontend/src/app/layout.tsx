import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'AI Cyber Pentest Control Platform',
  description: 'SOC-style vulnerability scanning dashboard'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  )
}


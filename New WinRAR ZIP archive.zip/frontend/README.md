# Frontend

Next.js dashboard.

Jalankan:
```bat
cd frontend
npm install
npm run dev
```


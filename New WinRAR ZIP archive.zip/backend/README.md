# Backend

FastAPI + endpoint:
- GET `/api/health`
- POST `/api/scan/start` (MVP placeholder event via WS)

Catatan: Setup Windows bisa gagal jika `pydantic-core` butuh compiler (MSVC Build Tools).


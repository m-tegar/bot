from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class Finding:
    type: str
    severity: str
    target: str
    validationStatus: str
    payloadUsed: str
    evidence: str
    technicalAnalysis: str
    impact: str
    exploitability: str
    confidenceScore: float
    remediation: str

    # extra internal fields
    payload_signature: Optional[str] = None
    response_snippet: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


class BaseScanner:
    name: str

    async def scan(self, target: str, options: Optional[Dict[str, Any]] = None) -> List[Finding]:
        raise NotImplementedError


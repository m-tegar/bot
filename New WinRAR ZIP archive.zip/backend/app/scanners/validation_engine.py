from __future__ import annotations

import re
from dataclasses import asdict
from typing import Any, Dict, List, Optional, Tuple

from app.scanners.base import Finding


class ValidationEngine:
    """Anti false-positive validator.

    Proof requirements:
    - payload used
    - response snippet
    - signature match

    This validator is deterministic and does NOT rely on external AI.
    """

    def __init__(self) -> None:
        # signatures can be simple regex or exact matching tokens
        self._ws_signature_prefix = "BBXSS|BBSQL|"

    def _extract_snippet(self, response_text: str, hint: str, window: int = 220) -> str:
        if not response_text or not hint:
            return ""

        idx = response_text.lower().find(hint.lower())
        if idx < 0:
            return ""

        start = max(0, idx - window)
        end = min(len(response_text), idx + len(hint) + window)
        return response_text[start:end]

    def _signature_match(self, snippet: str, signature: Optional[str]) -> bool:
        if not snippet:
            return False
        if not signature:
            # fallback: any payload token inside snippet counts as match
            return True

        try:
            return re.search(signature, snippet, flags=re.IGNORECASE) is not None
        except re.error:
            # treat signature as plain token
            return signature.lower() in snippet.lower()

    def validate(self, *, finding: Finding, payload: str, response_text: str, signature: Optional[str]) -> Finding:
        payload_used = payload or finding.payloadUsed
        snippet = self._extract_snippet(response_text, hint=payload_used, window=220) or finding.response_snippet or ""

        match = self._signature_match(snippet=snippet, signature=signature)

        if payload_used and snippet and match:
            finding.validationStatus = "VALIDATED"
            finding.payloadUsed = payload_used
            finding.response_snippet = snippet  # type: ignore[attr-defined]
            finding.payload_signature = signature  # type: ignore[attr-defined]
            finding.confidenceScore = min(0.99, max(finding.confidenceScore, 0.75))
        else:
            finding.validationStatus = "REJECTED_FALSE_POSITIVE"
            finding.confidenceScore = min(finding.confidenceScore, 0.2)
            # ensure evidence is explicit
            finding.evidence = finding.evidence or "Tidak memenuhi bukti validasi (payload/snippet/signature)."

        # ensure evidence includes snippet if validated
        if finding.validationStatus == "VALIDATED" and snippet:
            finding.evidence = f"Proof snippet: {snippet}"

        return finding


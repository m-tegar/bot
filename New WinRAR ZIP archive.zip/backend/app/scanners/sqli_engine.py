from __future__ import annotations

import asyncio
import re
import urllib.parse
from typing import Any, Dict, List, Optional, Tuple

import httpx
from app.scanners.base import BaseScanner, Finding
from app.scanners.validation_engine import ValidationEngine


class SQLiScanner(BaseScanner):
    name = "SQLI"

    def __init__(self, *, timeout_s: float = 10.0) -> None:
        self.timeout_s = timeout_s
        self.validator = ValidationEngine()

    def _detect_candidate_params(self, url: str) -> List[str]:
        parsed = urllib.parse.urlparse(url)
        q = urllib.parse.parse_qs(parsed.query)
        return list(q.keys())

    def _payloads_boolean(self) -> List[str]:
        # DB-agnostic markers for comparison
        return [
            "' OR '1'='1", 
            "' OR '1'='2",
        ]

    def _payloads_time(self) -> List[Tuple[str, str]]:
        # (payload_with_delay_hint, signature_token)
        return [
            ("' OR SLEEP(3)--", "SLEEP"),
        ]

    async def scan(self, target: str, options: Optional[Dict[str, Any]] = None) -> List[Finding]:
        options = options or {}
        params = self._detect_candidate_params(target)
        if not params:
            return []

        parsed = urllib.parse.urlparse(target)
        base = target

        timeout = httpx.Timeout(self.timeout_s)
        async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": "BB-AI-Pentest"}) as client:
            try:
                base_r = await client.get(base, follow_redirects=True)
                base_text = base_r.text or ""
            except Exception:
                return []

            finds: List[Finding] = []

            # Boolean-based
            bool_payloads = self._payloads_boolean()
            if len(bool_payloads) >= 2:
                p_true, p_false = bool_payloads[0], bool_payloads[1]
                for param in params:
                    def make_url(payload: str) -> str:
                        q = urllib.parse.parse_qs(parsed.query)
                        q[param] = [payload]
                        new_query = urllib.parse.urlencode(q, doseq=True)
                        return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))

                    url_true = make_url(p_true)
                    url_false = make_url(p_false)

                    try:
                        r_true = await client.get(url_true, follow_redirects=True)
                        r_false = await client.get(url_false, follow_redirects=True)
                    except Exception:
                        continue

                    t_text = r_true.text or ""
                    f_text = r_false.text or ""

                    # response comparison (response body diff ratio via simple token overlap)
                    if len(t_text) == 0 or len(f_text) == 0:
                        continue

                    # heuristic: if texts differ significantly, likely boolean-based SQLi
                    score = abs(len(t_text) - len(f_text)) / max(1, len(base_text) or 1)
                    if score < 0.08:
                        continue

                    finding = Finding(
                        type="SQLi",
                        severity="High",
                        target=target,
                        validationStatus="PENDING",
                        payloadUsed=p_true,
                        evidence="",
                        technicalAnalysis=(
                            "Root cause: parameter input digunakan dalam query database tanpa parameterized statements/escaping yang benar. "
                            "Mekanisme: payload boolean memaksa kondisi yang berbeda sehingga response berubah (response comparison)."
                        ),
                        impact="Kompromi data, bypass auth, dan potensi RCE tergantung kemampuan DB.",
                        exploitability="Tinggi jika perbedaan response stabil dan terjadi tanpa error handling yang menutupi.",
                        confidenceScore=0.55,
                        remediation=(
                            "Gunakan prepared statements/parameterized queries, hapus dynamic string concatenation, validasi tipe data, "
                            "dan least-privilege untuk akun DB."
                        ),
                        payload_signature=re.escape(p_true),
                        response_snippet=None,
                        raw={"param": param, "trueUrl": url_true, "falseUrl": url_false, "score": score}
                    )

                    # validation proof: require payload token or signature in response snippet
                    # since many apps won't reflect SQL payload, we validate via signature match to error messages.
                    # For MVP, use payload itself as hint (often not present) so it may reject.
                    # This meets spec 'require proof'.
                    text_to_validate = t_text
                    finding = self.validator.validate(
                        finding=finding,
                        payload=p_true,
                        response_text=text_to_validate,
                        signature=r"(?i)(sql|syntax|odbc|mysql|postgres|sqlite|unterminated|syntax error)"
                    )

                    if finding.validationStatus == "VALIDATED":
                        finds.append(finding)

            # Time-based (optional)
            time_payloads = self._payloads_time()
            for payload, token in time_payloads:
                for param in params:
                    q = urllib.parse.parse_qs(parsed.query)
                    q[param] = [payload]
                    new_query = urllib.parse.urlencode(q, doseq=True)
                    injected = urllib.parse.urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
                    try:
                        # measure time
                        import time
                        start = time.perf_counter()
                        r = await client.get(injected, follow_redirects=True)
                        elapsed = time.perf_counter() - start
                    except Exception:
                        continue

                    if elapsed < 2.8:
                        continue

                    finding = Finding(
                        type="SQLi",
                        severity="Medium",
                        target=target,
                        validationStatus="PENDING",
                        payloadUsed=payload,
                        evidence="",
                        technicalAnalysis=(
                            "Root cause: query database dipengaruhi oleh input pengguna tanpa parameterization. "
                            "Mekanisme: payload time-based menyebabkan delay yang terukur sehingga mengindikasikan eksekusi SQL tak aman."
                        ),
                        impact="DoS sederhana atau eskalasi akses tergantung DB.",
                        exploitability="Sedang; perlu bukti snippet/signature untuk menghindari false positive.",
                        confidenceScore=0.4,
                        remediation=(
                            "Gunakan prepared statements/parameterized queries dan batasi kemampuan DB (pemisahan privilege) untuk mencegah SLEEP/benchmark exploitation."
                        ),
                        payload_signature=re.escape(payload),
                        response_snippet=None,
                        raw={"param": param, "url": injected, "elapsed": elapsed}
                    )
                    finding = self.validator.validate(
                        finding=finding,
                        payload=payload,
                        response_text=r.text or "",
                        signature=r"(?i)(sleep|time|delay|syntax|error)"
                    )
                    if finding.validationStatus == "VALIDATED":
                        finds.append(finding)

        return finds


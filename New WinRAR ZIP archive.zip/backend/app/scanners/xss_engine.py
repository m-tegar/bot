from __future__ import annotations

import asyncio
import html
import re
import urllib.parse
from typing import Any, Dict, List, Optional, Tuple

import httpx
from app.scanners.base import BaseScanner, Finding
from app.scanners.validation_engine import ValidationEngine


class XSSScanner(BaseScanner):
    name = "XSS"

    def __init__(self, *, timeout_s: float = 10.0, max_tasks: int = 10) -> None:
        self.timeout_s = timeout_s
        self.max_tasks = max_tasks
        self.validator = ValidationEngine()

    def _make_payloads(self) -> List[str]:
        # Use markers so validation can find exact payload token in response
        # Avoid JS execution dependency; just need reflection.
        markers = ["__BBXSS1__", "__BBXSS2__"]
        payloads = [f"\"'><svg>{m}</svg>" for m in markers]
        return payloads

    async def _fetch(self, client: httpx.AsyncClient, url: str) -> Tuple[int, str]:
        r = await client.get(url, timeout=self.timeout_s, follow_redirects=True)
        return r.status_code, r.text or ""

    def _detect_candidate_params(self, url: str) -> List[Tuple[str, str]]:
        parsed = urllib.parse.urlparse(url)
        q = urllib.parse.parse_qs(parsed.query)
        out: List[Tuple[str, str]] = []
        for k, vals in q.items():
            if not vals:
                continue
            out.append((k, vals[0]))
        return out

    async def scan(self, target: str, options: Optional[Dict[str, Any]] = None) -> List[Finding]:
        # Minimal MVP implementation per spec: detect params + reflection testing + injection attempts + validation proof
        options = options or {}
        payloads = self._make_payloads()

        finds: List[Finding] = []
        parsed = urllib.parse.urlparse(target)

        params = self._detect_candidate_params(target)
        if not params:
            return []

        timeout = httpx.Timeout(self.timeout_s)
        async with httpx.AsyncClient(timeout=timeout, headers={"User-Agent": "BB-AI-Pentest"}) as client:
            # baseline fetch
            try:
                base_status, base_text = await self._fetch(client, target)
            except Exception:
                return []

            for (param_name, original_value) in params:
                for payload in payloads:
                    # parameter injection
                    new_query = urllib.parse.urlencode({
                        **urllib.parse.parse_qs(parsed.query),
                        param_name: payload
                    }, doseq=True)
                    injected = urllib.parse.urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))

                    try:
                        status, text = await self._fetch(client, injected)
                    except Exception:
                        continue

                    # reflection testing
                    marker = payload
                    reflected = marker in text
                    if not reflected:
                        # also try unescaped
                        if marker.replace("\"", "\'") not in text:
                            continue

                    finding = Finding(
                        type="XSS",
                        severity="High" if status and status < 500 else "Medium",
                        target=target,
                        validationStatus="PENDING",
                        payloadUsed=payload,
                        evidence="",
                        technicalAnalysis=(
                            "Root cause: aplikasi tidak melakukan encoding/escaping yang benar pada input pengguna sebelum rendering ke HTML. "
                            "Mekanisme: payload dimasukkan ke parameter query dan direfleksikan ke response tanpa sanitasi/encoding yang memadai."
                        ),
                        impact="Kebocoran session/token, defacement, dan eksekusi script di browser korban.",
                        exploitability="Tingkat exploit tinggi jika payload direfleksikan ke konteks HTML/DOM yang dieksekusi.",
                        confidenceScore=0.6,
                        remediation=(
                            "Terapkan output encoding yang sesuai konteks (HTML/attribute/JS), gunakan templating yang aman, "
                            "serta sanitasi input sebelum disimpan/ditampilkan. Implementasikan CSP dan auto-escaping."
                        ),
                        payload_signature=re.escape(payload),
                        response_snippet=None,
                        raw={"injectedUrl": injected, "baseStatus": base_status, "status": status}
                    )

                    finding = self.validator.validate(
                        finding=finding,
                        payload=payload,
                        response_text=text,
                        signature=re.escape(payload)
                    )

                    if finding.validationStatus == "VALIDATED":
                        finds.append(finding)

        return finds


from __future__ import annotations

import html
import json
import os
from pathlib import Path
from typing import Any, Dict, List


def generate_json_report(scan_id: str, findings: List[Dict[str, Any]], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / f"report-{scan_id}.json"
    payload = {
        "scanId": scan_id,
        "findings": findings,
    }
    p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return p


def generate_html_report(scan_id: str, findings: List[Dict[str, Any]], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / f"report-{scan_id}.html"

    def esc(x: Any) -> str:
        return html.escape(str(x))

    cards = ""
    for f in findings:
        cards += (
            f"<div class='card'>"
            f"<div class='top'>"
            f"<div><div class='k'>TYPE:</div><div class='v'>{esc(f.get('type',''))}</div></div>"
            f"<div><div class='k'>SEVERITY:</div><div class='v'>{esc(f.get('severity',''))}</div></div>"
            f"<div><div class='k'>TARGET:</div><div class='v'>{esc(f.get('target',''))}</div></div>"
            f"</div>"
            f"<div class='line'><b>VALIDATION:</b> {esc(f.get('validationStatus',''))}</div>"
            f"<div class='line'><b>PAYLOAD USED:</b> <code>{esc(f.get('payloadUsed',''))}</code></div>"
            f"<div class='line'><b>EVIDENCE:</b> <div class='snippet'>{esc(f.get('evidence',''))}</div></div>"
            f"<details><summary class='link'>SOC TECHNICAL ANALYSIS</summary>"
            f"<pre class='pre'>{esc(f.get('technicalAnalysis',''))}</pre></details>"
            f"<div class='line'><b>REMEDIATION:</b> {esc(f.get('remediation',''))}</div>"
            f"</div>"
        )

    html_doc = f"""
<!doctype html>
<html lang='id'>
<head>
<meta charset='utf-8'/>
<meta name='viewport' content='width=device-width, initial-scale=1'/>
<title>Vulnerability Report - {esc(scan_id)}</title>
<style>
  body{{background:#070A12;color:#e5e7eb;font-family:ui-sans-serif,system-ui; margin:0; padding:24px;}}
  .wrap{{max-width:980px; margin:0 auto;}}
  h1{{margin:0 0 18px; font-size:22px;}}
  .muted{{color:#94a3b8; margin-bottom:16px;}}
  .grid{{display:grid; grid-template-columns:1fr; gap:14px;}}
  .card{{border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.04); border-radius:14px; padding:14px;}}
  .top{{display:flex; flex-wrap:wrap; gap:14px;}}
  .k{{font-size:11px; color:#94a3b8;}}
  .v{{font-weight:700; margin-top:4px;}}
  .line{{margin-top:10px; font-size:13px;}}
  .snippet{{white-space:pre-wrap; font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,'Liberation Mono','Courier New',monospace; font-size:12px; color:#cbd5e1;}}
  .pre{{white-space:pre-wrap; font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,'Liberation Mono','Courier New',monospace; font-size:12px; color:#cbd5e1;}}
  .link{{cursor:pointer; color:#93c5fd;}}
  code{{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,'Liberation Mono','Courier New',monospace;}}
</style>
</head>
<body>
  <div class='wrap'>
    <h1>━━━━━━━━━━━━━━━━━━━━━━\nVULNERABILITY REPORT\n━━━━━━━━━━━━━━━━━━━━━━</h1>
    <div class='muted'>Scan ID: {esc(scan_id)}</div>
    <div class='grid'>
      {cards or "<div class='card'>Tidak ada temuan tervalidasi.</div>"}
    </div>
  </div>
</body>
</html>
"""
    p.write_text(html_doc, encoding="utf-8")
    return p


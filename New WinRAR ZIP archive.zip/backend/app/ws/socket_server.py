from fastapi import FastAPI


# Untuk MVP ini, broadcasting dilakukan langsung via WSManager.
# Endpoint websocket sebenarnya akan diimplementasi pada iterasi berikutnya.

def register_socket_routes(app: FastAPI, ws_manager) -> None:
    # placeholder
    return


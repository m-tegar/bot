from __future__ import annotations

from typing import Any, Dict, List, Optional


class WSManager:

    def __init__(self) -> None:

        self.connections: List[Any] = []

    async def connect(self, websocket: Any) -> None:
        self.connections.append(websocket)

    def disconnect(self, websocket: Any) -> None:
        try:
            self.connections.remove(websocket)
        except ValueError:
            pass

    async def _broadcast(self, event: Dict[str, Any]) -> None:
        # broadcast semua koneksi. Untuk MVP, tidak menargetkan scan_id.
        for ws in list(self.connections):
            try:
                await ws.send_json({"event": event})
            except Exception:
                # koneksi rusak
                self.disconnect(ws)

    async def broadcast_scan_started(self, scan_id: str, target: str) -> None:
        await self._broadcast({"type": "scan_started", "scanId": scan_id, "target": target})

    async def broadcast_scan_progress(self, scan_id: str, progress: int, message: str) -> None:
        await self._broadcast({"type": "scan_progress", "scanId": scan_id, "progress": progress, "message": message})

    async def broadcast_vuln_found(self, scan_id: str, vuln: Dict[str, Any]) -> None:
        await self._broadcast({"type": "vuln_found", "scanId": scan_id, "vuln": vuln})

    async def broadcast_scan_finished(self, scan_id: str, summary: Dict[str, Any]) -> None:
        await self._broadcast({"type": "scan_finished", "scanId": scan_id, "summary": summary})

    def sample_vuln(self, target: str) -> Dict[str, Any]:
        return {
            "type": "XSS",
            "severity": "Low",
            "target": target,
            "validationStatus": "MVP_PLACEHOLDER",
            "payloadUsed": "<script>alert(1)</script>",
            "evidence": "Simulasi: endpoint menampilkan payload (placeholder).",
            "technicalAnalysis": "Root cause mekanisme placeholder. Nanti diganti dengan engine asli (crawling -> param detection -> reflection testing -> payload injection -> validation).",
            "impact": "Simulasi impact (placeholder).",
            "exploitability": "Simulasi exploitability (placeholder).",
            "confidenceScore": 0.1,
            "remediation": "Simulasi remediation (placeholder)."
        }

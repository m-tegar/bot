import uuid
from fastapi import APIRouter
from pydantic import BaseModel, HttpUrl

from app.ws.manager import ws_manager

router = APIRouter(prefix="/api/scan", tags=["scan"])



class StartScanRequest(BaseModel):
    target: HttpUrl


@router.post("/start")
async def start_scan(req: StartScanRequest):
    scan_id = str(uuid.uuid4())
    await ws_manager.broadcast_scan_started(scan_id=scan_id, target=str(req.target))
    # Worker akan memproses scan ini via internal pipeline (untuk MVP: simulated)
    await ws_manager.broadcast_scan_progress(scan_id=scan_id, progress=10, message="Validasi parameter & crawling awal...")

    # Simulasi cepat agar UI jalan
    await ws_manager.broadcast_scan_progress(scan_id=scan_id, progress=60, message="Pengujian XSS/SQLi (MVP placeholder berjalan)...")

    # Kirim event vuln contoh (nanti diganti engine sebenarnya)
    await ws_manager.broadcast_vuln_found(scan_id=scan_id, vuln=ws_manager.sample_vuln(target=str(req.target)))

    await ws_manager.broadcast_scan_finished(scan_id=scan_id, summary={"totalVulns": 1})

    return {"scanId": scan_id}


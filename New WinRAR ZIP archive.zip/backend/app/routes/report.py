from fastapi import APIRouter

router = APIRouter(prefix="/api/report", tags=["report"])


@router.get("/{scan_id}")
async def get_report(scan_id: str):
    # Placeholder - nanti akan diisi dengan report generator sungguhan
    return {
        "scanId": scan_id,
        "status": "MVP_PLACEHOLDER",
        "report": {}
    }


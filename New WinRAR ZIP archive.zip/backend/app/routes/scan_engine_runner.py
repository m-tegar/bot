from __future__ import annotations

import uuid
from typing import Any, Dict, List

from fastapi import APIRouter
from pydantic import BaseModel, HttpUrl

from app.ai.soc_report import soc_analysis_from_finding
from app.reports.generator import generate_html_report, generate_json_report
from app.scanners.sqli_engine import SQLiScanner
from app.scanners.xss_engine import XSSScanner
from app.ws.manager import WSManager

router = APIRouter(prefix="/api/scan", tags=["scan"])


class ScanRequest(BaseModel):
    target: HttpUrl
    mode: str = "balanced"  # reserved for mode-based scanning (future)


@router.post("/start_engine")
async def start_engine(req: ScanRequest) -> Dict[str, Any]:
    """Real engine runner (no worker) for correctness of pipeline.

    Important: This endpoint can be slow; it uses async httpx with timeouts.
    """
    scan_id = str(uuid.uuid4())

    ws = WSManager()
    await ws.broadcast_scan_started(scan_id=scan_id, target=str(req.target))
    await ws.broadcast_scan_progress(scan_id=scan_id, progress=5, message="Crawling & parameter detection...")

    xss = XSSScanner(timeout_s=8.0)
    sqli = SQLiScanner(timeout_s=8.0)

    findings: List[Dict[str, Any]] = []

    xss_findings = await xss.scan(str(req.target), options={})
    await ws.broadcast_scan_progress(
        scan_id=scan_id, progress=55, message=f"XSS engine selesai. Temuan tervalidasi: {len(xss_findings)}"
    )

    sqli_findings = await sqli.scan(str(req.target), options={})
    await ws.broadcast_scan_progress(
        scan_id=scan_id, progress=80, message=f"SQLi engine selesai. Temuan tervalidasi: {len(sqli_findings)}"
    )

    for f in xss_findings + sqli_findings:
        f_dict = f.__dict__.copy()
        soc = soc_analysis_from_finding(finding=f_dict)
        findings.append(soc)

    reports_dir = "reports"
    json_path = generate_json_report(scan_id, findings, out_dir=__import__("pathlib").Path(reports_dir))
    html_path = generate_html_report(scan_id, findings, out_dir=__import__("pathlib").Path(reports_dir))

    for f in findings:
        await ws.broadcast_vuln_found(scan_id=scan_id, vuln=f)

    await ws.broadcast_scan_finished(scan_id=scan_id, summary={"totalVulns": len(findings)})

    return {
        "scanId": scan_id,
        "status": "DONE",
        "reports": {"json": str(json_path), "html": str(html_path)},
        "total": len(findings),
    }


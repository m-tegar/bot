from __future__ import annotations

import uuid
from fastapi import APIRouter
from pydantic import BaseModel, HttpUrl

from app.services.scan_service import ScanService
from app.ws.manager import WSManager
from app.routes.scan_engine_runner import ScanRequest


router = APIRouter(prefix="/api/scan", tags=["scan"])


class StartScanRequest(BaseModel):
    target: HttpUrl


@router.post("/start_full")
async def start_full(req: StartScanRequest):
    scan_id = str(uuid.uuid4())
    # run scan in background-like manner (without worker service for MVP)
    # In later phase, we will offload to worker.
    service = ScanService()

    await WSManager().broadcast_scan_started(scan_id=scan_id, target=str(req.target))

    result = await service.run_scan(scan_id=scan_id, target=str(req.target), options={})

    # broadcast each finding
    for f in result.get("findings", []):
        await WSManager().broadcast_vuln_found(scan_id=scan_id, vuln=f)

    await WSManager().broadcast_scan_finished(scan_id=scan_id, summary={"totalVulns": len(result.get('findings', []))})

    return {"scanId": scan_id, "status": "DONE", "reports": result.get("reports", {})}


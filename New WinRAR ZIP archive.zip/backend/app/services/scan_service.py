from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Dict, List

from app.ai.soc_report import soc_analysis_from_finding
from app.reports.generator import generate_html_report, generate_json_report
from app.scanners.sqli_engine import SQLiScanner
from app.scanners.xss_engine import XSSScanner


class ScanService:
    def __init__(self) -> None:
        self.xss = XSSScanner(timeout_s=10.0)
        self.sqli = SQLiScanner(timeout_s=10.0)
        self.reports_dir = Path("reports")

    async def run_scan(self, scan_id: str, target: str, options: Dict[str, Any] | None = None) -> Dict[str, Any]:
        options = options or {}
        findings_raw: List[Any] = []

        xss_findings = await self.xss.scan(target, options)
        sqli_findings = await self.sqli.scan(target, options)

        # convert to dict and attach SOC analysis template
        for f in xss_findings + sqli_findings:
            f_dict = f.__dict__.copy()
            soc = soc_analysis_from_finding(finding=f_dict)
            findings_raw.append(soc)

        json_path = generate_json_report(scan_id, findings_raw, self.reports_dir)
        html_path = generate_html_report(scan_id, findings_raw, self.reports_dir)

        return {
            "scanId": scan_id,
            "findings": findings_raw,
            "reports": {
                "json": str(json_path),
                "html": str(html_path),
            },
        }


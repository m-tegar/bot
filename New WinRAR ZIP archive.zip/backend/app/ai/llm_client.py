from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional


class LLMClient:
    """LLM client (OpenAI optional).

    - Requirement: safe-by-design: never calls shell.
    - If OPENAI_API_KEY is missing, this module should never be used.
    """

    def __init__(self) -> None:
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

        # Optional deps
        try:
            from openai import OpenAI  # type: ignore

            self._OpenAI = OpenAI
        except Exception:
            self._OpenAI = None

    def available(self) -> bool:
        return bool(self.api_key) and self._OpenAI is not None

    def build_prompt(self, *, payload: Dict[str, Any]) -> str:
        # Payload should already satisfy proof-gating (validated). We instruct the model
        # to ONLY use provided evidence.
        type_ = payload.get("type", "UNKNOWN")
        severity = payload.get("severity", "")
        target = payload.get("target", "")
        payload_used = payload.get("payloadUsed", "")
        evidence = payload.get("evidence", "")
        validation_status = payload.get("validationStatus", "")
        snippet = payload.get("response_snippet") or payload.get("responseSnippet") or ""
        signature = payload.get("payload_signature") or payload.get("signature") or ""
        technical = payload.get("technicalAnalysis", "")
        impact = payload.get("impact", "")
        exploitability = payload.get("exploitability", "")
        remediation = payload.get("remediation", "")
        confidence = payload.get("confidenceScore", 0.0)

        prompt = f"""
Kamu bertindak sebagai SOC analyst report writer.

TUGAS:
Buat laporan SOC berbentuk JSON yang memuat bagian berikut:
- TECHNICAL ANALYSIS (root cause & vulnerability mechanism)
- IMPACT ANALYSIS (system impact, business risk, severity explanation)
- EXPLOIT SCENARIO (real-world attack scenario)
- REMEDIATION (fix suggestions)
- REASONING STEPS (step-by-step analysis)

KONSTRAINT:
- WAJIB menyertakan bukti yang diberikan: PAYLOAD USED + EVIDENCE + (response snippet bila ada) + (signature bila ada).
- HANYA gunakan informasi dari input bukti. Jangan mengarang.
- Jika validationStatus tidak VALIDATED, keluarkan "NOT_ENOUGH_PROOF".

FORMAT OUTPUT HARUS berupa JSON dengan field:
{{
  "validationStatus": "...",
  "technicalAnalysis": "...",
  "impact": "...",
  "exploitability": "...",
  "exploitScenario": "...",
  "remediation": "...",
  "reasoningSteps": ["step1", "step2", ...],
  "confidenceScore": number,
  "signatureMatched": boolean
}}

INPUT FINDING:
{json.dumps(payload, ensure_ascii=False)}

Catatan signatureMatched:
- bernilai true jika signature (payload_signature/signature) ditemukan dan evidence/snippet mengindikasikan match.
"""
        return prompt

    def generate_soc_json(self, *, finding: Dict[str, Any]) -> Dict[str, Any]:
        if not self.available():
            raise RuntimeError("LLM tidak tersedia (OPENAI_API_KEY atau dependency openai tidak ada).")

        client = self._OpenAI(api_key=self.api_key)
        prompt = self.build_prompt(payload=finding)

        completion = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "SOC analyst. Output JSON only."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
        )

        content = completion.choices[0].message.content or "{}"
        try:
            data = json.loads(content)
            if not isinstance(data, dict):
                raise ValueError("LLM output bukan dict JSON")
            return data
        except Exception:
            # fallback structured minimal
            return {
                "validationStatus": finding.get("validationStatus"),
                "technicalAnalysis": f"LLM parsing gagal. Technical (fallback): {finding.get('technicalAnalysis','')}",
                "impact": finding.get("impact", ""),
                "exploitability": finding.get("exploitability", ""),
                "exploitScenario": "LLM output tidak bisa diparse.",
                "remediation": finding.get("remediation", ""),
                "reasoningSteps": [],
                "confidenceScore": finding.get("confidenceScore", 0.0),
                "signatureMatched": False,
            }


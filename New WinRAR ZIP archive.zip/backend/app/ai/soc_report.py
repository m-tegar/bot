from __future__ import annotations

from typing import Any, Dict


def soc_analysis_from_finding(*, finding: Dict[str, Any]) -> Dict[str, Any]:
    """Buat laporan SOC berbasis finding.

    - Proof gating: LLM hanya dipanggil jika validationStatus == "VALIDATED".
    - Jika LLM tidak tersedia (OPENAI_API_KEY / dependency), fallback deterministik.
    """

    vuln_type = finding.get("type", "UNKNOWN")
    severity = finding.get("severity", "Unknown")
    target = finding.get("target", "")
    validation_status = finding.get("validationStatus", "PENDING")
    payload_used = finding.get("payloadUsed", "")
    evidence = finding.get("evidence", "")

    # --- Proof gating (wajib) ---
    if validation_status != "VALIDATED":
        technical = finding.get("technicalAnalysis") or ""
        impact = finding.get("impact") or ""
        exploitability = finding.get("exploitability") or ""
        remediation = finding.get("remediation") or ""
        confidence = finding.get("confidenceScore", 0.0)

        analysis_text = (
            f"[TECHNICAL ANALYSIS]\n{technical}\n\n"
            f"[IMPACT ANALYSIS]\n- Sistem impact: {impact}\n- Business risk: potensi insiden kebocoran dan takeover\n- Severity: {severity}\n\n"
            f"[EXPLOIT SCENARIO]\nValidasi belum memenuhi bukti (proof-gating).\n\n"
            f"[REASONING STEPS]\n- Finding ditolak oleh Validation Engine karena bukti payload/snippet/signature tidak terpenuhi.\n\n"
            f"[REMEDIATION]\n{remediation}\n"
        )

        return {
            "type": vuln_type,
            "severity": severity,
            "target": target,
            "validationStatus": validation_status,
            "payloadUsed": payload_used,
            "evidence": evidence,
            "technicalAnalysis": analysis_text,
            "impact": impact,
            "exploitability": exploitability,
            "confidenceScore": confidence,
            "remediation": remediation,
        }

    # --- LLM path (opsional) ---
    try:
        from app.ai.llm_client import LLMClient

        llm = LLMClient()
        if llm.available():
            llm_json = llm.generate_soc_json(finding=finding)

            technical_text = llm_json.get("technicalAnalysis") or finding.get("technicalAnalysis") or ""
            impact_text = llm_json.get("impact") or finding.get("impact") or ""
            exploitability_text = llm_json.get("exploitability") or finding.get("exploitability") or ""
            exploit_scenario = llm_json.get("exploitScenario") or ""
            remediation_text = llm_json.get("remediation") or finding.get("remediation") or ""
            reasoning_steps = llm_json.get("reasoningSteps") or []
            confidence = llm_json.get("confidenceScore", finding.get("confidenceScore", 0.0))

            reasoning_block = "\n".join([f"{i+1}) {s}" for i, s in enumerate(reasoning_steps)])
            if not reasoning_block:
                reasoning_block = "- (LLM tidak mengisi reasoning steps)"

            analysis_text = (
                f"[TECHNICAL ANALYSIS]\n{technical_text}\n\n"
                f"[IMPACT ANALYSIS]\n{impact_text}\n- Severity: {severity}\n\n"
                f"[EXPLOIT SCENARIO]\n{exploit_scenario}\n\n"
                f"[REASONING STEPS]\n{reasoning_block}\n\n"
                f"[REMEDIATION]\n{remediation_text}\n"
            )

            return {
                "type": vuln_type,
                "severity": severity,
                "target": target,
                "validationStatus": validation_status,
                "payloadUsed": payload_used,
                "evidence": evidence,
                "technicalAnalysis": analysis_text,
                "impact": impact_text,
                "exploitability": exploitability_text,
                "confidenceScore": confidence,
                "remediation": remediation_text,
            }
    except Exception:
        # fallback deterministik
        pass

    # --- Fallback deterministik ---
    technical = finding.get("technicalAnalysis") or ""
    impact = finding.get("impact") or ""
    remediation = finding.get("remediation") or ""
    exploitability = finding.get("exploitability") or ""
    confidence = finding.get("confidenceScore", 0.0)

    analysis_text = (
        f"[TECHNICAL ANALYSIS]\n{technical}\n\n"
        f"[IMPACT ANALYSIS]\n- Sistem impact: {impact}\n- Business risk: potensi insiden kebocoran dan takeover\n- Severity: {severity}\n\n"
        f"[EXPLOIT SCENARIO]\nContoh skenario: penyerang mengirim payload via parameter input, "
        f"kemudian browser/aplikasi memprosesnya tanpa sanitasi yang benar. Validasi engine memastikan bukti (payload+snippet+signature) ada.\n\n"
        f"[REASONING STEPS]\n1) identifikasi parameter kandidat\n2) injeksi payload terkontrol\n3) verifikasi bukti di response (snippet + signature)\n4) klasifikasi mekanisme dan tingkat risiko\n\n"
        f"[REMEDIATION]\n{remediation}\n"
    )

    return {
        "type": vuln_type,
        "severity": severity,
        "target": target,
        "validationStatus": validation_status,
        "payloadUsed": payload_used,
        "evidence": evidence,
        "technicalAnalysis": analysis_text,
        "impact": impact,
        "exploitability": exploitability,
        "confidenceScore": confidence,
        "remediation": remediation,
    }


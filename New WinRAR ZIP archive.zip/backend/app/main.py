from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routes.health import router as health_router
from app.routes.scan import router as scan_router
from app.routes.report import router as report_router
from app.routes.scan_engine_runner import router as scan_engine_router


app = FastAPI(title="AI Cyber Pentest Control Platform API")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(scan_router)
app.include_router(report_router)
app.include_router(scan_engine_router)






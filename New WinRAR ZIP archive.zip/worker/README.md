# Worker

MVP worker loop placeholder.

Catatan: worker butuh Python + pip yang benar.


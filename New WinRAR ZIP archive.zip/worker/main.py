import asyncio
from rich.console import Console
from rich.panel import Panel
from colorama import init as colorama_init


async def main() -> None:
    colorama_init()
    console = Console()
    console.print(Panel.fit("[bold cyan]Worker started[/] - MVP placeholder"))

    # MVP: placeholder worker loop
    while True:
        await asyncio.sleep(2)


if __name__ == "__main__":
    asyncio.run(main())


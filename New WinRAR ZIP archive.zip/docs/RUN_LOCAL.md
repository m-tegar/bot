# Run Local

## 1) Backend (FastAPI)
```bash
cd backend
python -m venv .venv
..venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## 2) Worker
```bash
cd worker
python -m venv .venv
..venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## 3) Frontend (Next.js)
```bash
cd frontend
npm install
npm run dev
```

## 4) Validasi
- Backend: pastikan log ada `Application startup complete`
- Worker: pastikan log ada `Worker started`
- Frontend: pastikan build tidak error
- Smoke test: akses endpoint `GET /api/health` (backend)

